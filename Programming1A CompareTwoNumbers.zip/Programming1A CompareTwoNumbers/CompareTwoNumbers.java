public class CompareTwoNumbers {
    
static public void main(String[] arg){
    
    int num1,num2;
    num1=50;
    num2=20;
    
    if (num1>num2)
    System.out.println(num1+">"+num2);
    else
    System.out.println(num2+">"+num1);
}
    
}
